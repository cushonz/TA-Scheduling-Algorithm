Group 5

Project Report – Feasibility

CS 480

January 16, 2022

The plan is to use C++ and using Visual Studio Code to complete this project. As far as my group and I are concerned, we are supposed to make some type of scheduler for CWU TA’s (CS 392/CS492) to use and help make their job easier and more organized. To this extent our group have made up our own discord to make communicating better and more efficient. This way we can see and understand how each of us are contributing to the project. This will keep each of us up to date with what is going on with our project.

What tools & technology do we plan on using?  As I discussed, we are using Visual Studio Code. I am still a little new to this program so it will be a challenge for me. One of my classes is going over this type of program so it should help me keep ahead of the curve. Also, I will be using the 2022 version of the software and will be using this program to do my portion of the project. At least this is what the group is planning at this time.  

How dose our group plan to organize things? Discord helps to keep our group more organized. We can set up different rooms, such as a general chat to program to help. This will keep the group focused on the things that we should be focusing on. This will also support us in locating and finding past data and/or communications that we may need.

What does our group need from the client? What we need from the client is some raw data so we can use it to help work through the piece of data that we must include in the output. So that we have a handle on what is expected or needed from this project. Also, it would be nice to know how much knowledge they have of the program software so we can composite or that.

The current state of our project is a few examples of basic code that we can oversee and look into to reference back to and possibly improve what we have.

Our next plan will be to start the main program process and see what we need to work on. Possibly find some issues and work through them together using our separate levels of knowledge. 

